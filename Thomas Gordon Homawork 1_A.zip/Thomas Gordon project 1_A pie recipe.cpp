////////////////////////////////////////////////////
//Thomas Gordon                                   //
//Date: 9-3-17                                    //
//Assignment: malikai's pie recipe (project 1_A)  //
//class: COP2000 intro to computer programing(C++)//
////////////////////////////////////////////////////


//staring the program
#include<iostream>
#include<iomanip>
using namespace std;

//starting the function int main()
int main()
{
//listing variables and constant variables while starting a calculation
	int user_input;
	const float num_crusts = 6,
				cups_flour = 15 / num_crusts,
				tbsp_sugar = 8 / num_crusts,
				tbsp_salt = 3 / num_crusts,
				cups_butter = 5.25 / num_crusts,
				large_eggs = 6 / num_crusts;

	//prompting and title
	cout << "welcome to Malakai's Pie Shop " << endl << endl;
	cout << "enter the amount of pie crusts you will need to make: " << endl;
	
	//get user input
	cin >> user_input; 
	
	//meant to go on to the next line for the cin statement 
	cout << endl;

	//output
	cout << "the amount of ingredients you will need are: " << endl;
	
	//listing variables and constant variables while completing a calculation
	float cups = cups_flour * user_input,
		tbsp = tbsp_sugar * user_input,
		name_tbsp = tbsp_salt * user_input,
		name_cups = cups_butter * user_input,
		eggs = large_eggs * user_input;
	//outputing the data with 2 decimal places to the left 
	cout << setprecision(2) << fixed << endl;
	
	cout << cups << " cups of flour" << endl;
	cout << tbsp << " tbsp of sugar" << endl;
	cout << name_tbsp << " tbsp of salt" << endl;
	cout << name_cups << " cups of butter" << endl;
	cout << eggs << " large eggs" << endl << endl;

	//ending the program
	system("pause");
	return 0;
}